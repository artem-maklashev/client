import React, { useEffect, useMemo, useState } from "react";
import GypsumBoard from "../../../model/gypsumBoard/GypsumBoard";
import BoardProduction from "../../../model/production/BoardProduction";
import ApiService from "../../../service/ApiService";
import MaterialConsumption from "../../../model/specification/MaterialConsumption";
import Material from "../../../model/specification/Material";
import { Card, Col, Container, ToggleButton, ToggleButtonGroup, ButtonGroup } from "react-bootstrap";
import { CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import Specification from "../../../model/specification/Specification";
import Thickness from "../../../model/gypsumBoard/Thickness";

interface ConsumptionChartProps {
    startDate: Date;
    endDate: Date;
    gypsumBoards: GypsumBoard[];
    material: Material | null;
}

interface ChartData {
    productionValue: number;
    consumption: number;
    consumptionPerSquare: number;
    rate: number;
}

interface CombinedData {
    date: string;
    consumptionPerSquare: number;
    rate: number;
    originalDate: Date;
}

interface CustomTooltipProps {
    active?: boolean;
    payload?: Array<{ payload: CombinedData }>;
}

type AggregationType = 'day' | 'month';

const ConsumptionChart: React.FC<ConsumptionChartProps> = ({ startDate, endDate, gypsumBoards, material }) => {
    const [productions, setProduction] = useState<BoardProduction[]>([]);
    const [consumptions, setConsumptions] = useState<MaterialConsumption[]>([]);
    const [data, setData] = useState<{ [date: string]: ChartData }>({});
    const [chartData, setChartData] = useState<CombinedData[]>([]);
    const [specifications, setSpecifications] = useState<Specification[]>([]);
    const [aggregationType, setAggregationType] = useState<AggregationType>('day');
    const [processingProgress, setProcessingProgress] = useState(0);
    const [isProcessing, setIsProcessing] = useState(false); // Добавлено состояние для отслеживания обработки

    const CustomTooltip: React.FC<CustomTooltipProps> = ({ active, payload }) => {
        if (active && payload && payload.length) {
            const { date, consumptionPerSquare, rate } = payload[0]?.payload || {};
            return (
                <div className="custom-tooltip" style={{ background: 'transparent' }}>
                    <strong>
                        <p className="label">{`Дата: ${date}`}</p>
                        <p className="intro">{`Расход факт: ${consumptionPerSquare.toFixed(4)}`}</p>
                        <p className="intro">{`Норма: ${rate.toFixed(4)}`}</p>
                        <p className="desc">{`Отклонение: ${(consumptionPerSquare - rate).toFixed(4)}`}</p>
                    </strong>
                </div>
            );
        }
        return null;
    };

    useEffect(() => {
        const fetchData = async () => {
            if (material) {
                const fetchedData = (await ApiService.fetchAllSpecifications()).filter(s => s.material.id === material.id);
                setSpecifications(fetchedData);
                console.log(fetchedData);
            }
        }
        fetchData();
    }, [material]);

    useEffect(() => {
        if (gypsumBoards) {
            const fetchProduction = async () => {
                const production = await ApiService.fetchBoardProductionByGypsumBoardAndDate(
                    gypsumBoards,
                    startDate,
                    endDate
                );
                setProduction(production);
            }
            fetchProduction();
        }
    }, [startDate, endDate, gypsumBoards]);

    useEffect(() => {
        if (material) {
            const fetchConsumption = async () => {
                const consumption = await ApiService.fetchConsumptionsByDateAndMaterial(
                    startDate,
                    endDate,
                    material.id
                );
                setConsumptions(consumption);
            }
            fetchConsumption();
        }
    }, [startDate, endDate, material]);

    const processData = async (
        productions: BoardProduction[],
        consumptions: MaterialConsumption[],
        aggregation: AggregationType,
        onProgress?: (progress: number) => void
    ): Promise<{ [date: string]: ChartData & { dateObj: Date } }> => {
        const draftData: { [date: string]: ChartData & { dateObj: Date } } = {};
        const totalItems = productions.length;

        for (let i = 0; i < productions.length; i++) {
            const production = productions[i];
            
            if (onProgress) {
                const progress = Math.round(((i + 1) / totalItems) * 100);
                onProgress(progress);
            }
            
            const originalDate = new Date(production.productionList.productionDate);
            let dateKey: string;
            let dateObj: Date;

            if (aggregation === 'month') {
                dateObj = new Date(originalDate.getFullYear(), originalDate.getMonth(), 1);
                dateKey = `${originalDate.getFullYear()}-${String(originalDate.getMonth() + 1).padStart(2, '0')}`;
            } else {
                dateObj = new Date(originalDate.getFullYear(), originalDate.getMonth(), originalDate.getDate());
                dateKey = originalDate.toLocaleDateString();
            }

            const consumption = consumptions.find(c => c.productionList.id === production.productionList.id)?.quantity || 0;
            const existingData = draftData[dateKey];
            const rate = specifications.find((s) => s.product.id === production.product.id);

            if (existingData) {
                existingData.rate += rate ? rate.quantity * production.value : 0;
                existingData.productionValue += production.value;
                existingData.consumption += consumption;
            } else {
                draftData[dateKey] = {
                    productionValue: production.value,
                    consumption,
                    consumptionPerSquare: 0,
                    rate: rate ? rate.quantity * production.value : 0,
                    dateObj: dateObj,
                };
            }
            
            if (i % 100 === 0) {
                await new Promise(resolve => setTimeout(resolve, 0));
            }
        }

        const dateKeys = Object.keys(draftData);
        for (let i = 0; i < dateKeys.length; i++) {
            const dateKey = dateKeys[i];
            const data = draftData[dateKey];
            data.consumptionPerSquare = data.productionValue !== 0 ? data.consumption / data.productionValue : 0;
            data.rate = data.rate / data.productionValue;
        }

        return draftData;
    };

    const formatXAxis = (dateKey: string, aggregation: AggregationType): string => {
        if (aggregation === 'month') {
            const [year, month] = dateKey.split('-');
            const date = new Date(parseInt(year), parseInt(month) - 1);
            return date.toLocaleDateString('ru-RU', { month: 'short', year: 'numeric' });
        }
        return dateKey;
    };

    // НОВЫЙ useEffect для обработки данных с прогресс-баром
    useEffect(() => {
        const updateChartData = async () => {
            if (productions.length > 0 && consumptions.length > 0 && specifications.length > 0) {
                setIsProcessing(true);
                setProcessingProgress(0);
                
                try {
                    const draftData = await processData(
                        productions, 
                        consumptions, 
                        aggregationType,
                        (progress) => setProcessingProgress(progress)
                    );
                    
                    const sortedEntries = Object.entries(draftData).sort((a, b) => 
                        a[1].dateObj.getTime() - b[1].dateObj.getTime()
                    );
                    
                    const combinedData: CombinedData[] = sortedEntries.map(([dateKey, value]) => ({
                        date: formatXAxis(dateKey, aggregationType),
                        consumptionPerSquare: value.consumptionPerSquare,
                        rate: value.rate,
                        originalDate: value.dateObj
                    }));
                    
                    setChartData(combinedData);
                } catch (error) {
                    console.error('Ошибка обработки данных:', error);
                } finally {
                    setIsProcessing(false);
                    setProcessingProgress(0);
                }
            } else if (productions.length === 0 && consumptions.length === 0) {
                setChartData([]);
            }
        };
        
        updateChartData();
    }, [consumptions, productions, specifications, aggregationType]);

    const ProgressBar = () => (
        <div className="text-center py-5">
            <div className="progress" style={{ height: '40px', borderRadius: '8px' }}>
                <div 
                    className="progress-bar progress-bar-striped progress-bar-animated bg-primary"
                    role="progressbar"
                    style={{ 
                        width: `${processingProgress}%`,
                        transition: 'width 0.3s ease',
                        fontSize: '14px',
                        fontWeight: 'bold',
                        lineHeight: '40px'
                    }}
                >
                    {processingProgress > 0 && `${processingProgress}%`}
                </div>
            </div>
            <p className="mt-3 text-muted">
                Обработка данных... {processingProgress}%
            </p>
        </div>
    );

    const legendFormatter = (value: string) => {
        switch (value) {
            case 'rate':
                return 'Норма';
            case 'consumptionPerSquare':
                return 'Факт';
            default:
                return value;
        }
    };

    return (
        <Container>
            <Card className="mt-lg-5 text-center bg-body-primary">
                <Card.Header>
                    <div className="d-flex justify-content-between align-items-center">
                        <h6 className="mb-0">
                            расход {material ? material.name : ""} на м²
                        </h6>
                        <ToggleButtonGroup
                            type="radio"
                            name="aggregation"
                            value={aggregationType}
                            onChange={(val) => val && setAggregationType(val as AggregationType)}
                            size="sm"
                            // disabled={isProcessing} // Блокируем переключатель во время обработки
                        >
                            <ToggleButton id="agg-day" value="day" variant="outline-primary">
                                По дням
                            </ToggleButton>
                            <ToggleButton id="agg-month" value="month" variant="outline-primary">
                                По месяцам
                            </ToggleButton>
                        </ToggleButtonGroup>
                    </div>
                </Card.Header>
                <Card.Body style={{ overflowX: 'auto' }}>
                    <Col className="col-12" style={{ minWidth: '500px', width: '100%', height: '278px' }}>
                        {isProcessing ? (
                            <ProgressBar />
                        ) : chartData.length === 0 ? (
                            <div className="text-center py-5">
                                <p className="text-muted">Нет данных для отображения</p>
                            </div>
                        ) : (
                            <ResponsiveContainer>
                                <LineChart
                                    width={500}
                                    height={300}
                                    data={chartData}
                                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                                >
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis 
                                        dataKey="date" 
                                        angle={aggregationType === 'month' ? -60 : -45}
                                        textAnchor={aggregationType === 'month' ? 'end' : 'end'}
                                        height={aggregationType === 'month' ? 60 : 80}
                                        interval={aggregationType === 'month' ? 0 : 'preserveStartEnd'}
                                    />
                                    <YAxis yAxisId="left" />
                                    <Tooltip content={<CustomTooltip />} />
                                    <Legend formatter={legendFormatter} />
                                    <Line yAxisId="left" type="monotone" dataKey="consumptionPerSquare" stroke="#8884d8" activeDot={{ r: 8 }} strokeWidth={3} />
                                    <Line yAxisId="left" type="monotone" dataKey="rate" stroke="#FF1493" activeDot={{ r: 8 }} strokeWidth={3} />
                                </LineChart>
                            </ResponsiveContainer>
                        )}
                    </Col>
                </Card.Body>
                <Card.Footer>
                    <p style={{ fontSize: 10 }}>{gypsumBoards.map((board) => ApiService.getName(board) + "    -    ")}</p>
                </Card.Footer>
            </Card>
        </Container>
    );
}

export default ConsumptionChart;